// This is the main DLL file.

#include "Entity.h"

Entity::Entity(void)
{

};

Entity::~Entity(void)
{
};

void Entity::Added()
{
	//renderedItem.Load();
};

void Entity::Update()
{
	//renderedItem.Update(frames);
};

void Entity::Render()
{
	//renderedItem.Render(position, renderedItem.GetRect());
};

void Entity::Removed()
{
	//renderedItem.Removed(eID);
};

void Entity::SetEntity(std::string eName, std::string eType)
{
	name = eName;
	type = eType;
};
