--[[
Audio core script file
]]--

MUSIC_VOLUME = 5
SOUND_VOLUME = 5
SOUND = "sound.wav"
MUSIC = "music.wav"
