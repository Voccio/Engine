//Combination of Latisha's and David's coding

#include "Graphics.h"




